﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileAddNew = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.FileSave = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.FileLogOut = New System.Windows.Forms.ToolStripMenuItem()
        Me.OperationMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.OperationBackUp = New System.Windows.Forms.ToolStripMenuItem()
        Me.OperationImport = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.OperationDelete = New System.Windows.Forms.ToolStripMenuItem()
        Me.OperationDeleteAll = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpReadMe = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpAbout = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.lbtips = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lbhelp = New System.Windows.Forms.ToolStripStatusLabel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.pLabel = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pCategory = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pUser = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pEmail = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pPhone = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pPassword = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pRecovery = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pNotes = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ButtonAddNew = New System.Windows.Forms.ToolStripButton()
        Me.ButtonEdit = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ButtonBackup = New System.Windows.Forms.ToolStripButton()
        Me.ButtonRestore = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ButtonDelete = New System.Windows.Forms.ToolStripButton()
        Me.ButtonDeleteAll = New System.Windows.Forms.ToolStripButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.TimerHelp = New System.Windows.Forms.Timer(Me.components)
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ContextEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContextDelete = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.White
        Me.MenuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileMenu, Me.OperationMenu, Me.HelpMenu})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.MenuStrip1.Size = New System.Drawing.Size(753, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileMenu
        '
        Me.FileMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileAddNew, Me.FileEdit, Me.ToolStripSeparator3, Me.FileSave, Me.ToolStripSeparator4, Me.FileLogOut})
        Me.FileMenu.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.FileMenu.Name = "FileMenu"
        Me.FileMenu.Size = New System.Drawing.Size(29, 20)
        Me.FileMenu.Text = "??"
        '
        'FileAddNew
        '
        Me.FileAddNew.Image = Global.SandiBox.My.Resources.Resources.add
        Me.FileAddNew.Name = "FileAddNew"
        Me.FileAddNew.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.FileAddNew.Size = New System.Drawing.Size(156, 22)
        Me.FileAddNew.Text = "??"
        '
        'FileEdit
        '
        Me.FileEdit.Image = Global.SandiBox.My.Resources.Resources.edit
        Me.FileEdit.Name = "FileEdit"
        Me.FileEdit.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.E), System.Windows.Forms.Keys)
        Me.FileEdit.Size = New System.Drawing.Size(156, 22)
        Me.FileEdit.Text = "??"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(153, 6)
        '
        'FileSave
        '
        Me.FileSave.Name = "FileSave"
        Me.FileSave.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.FileSave.Size = New System.Drawing.Size(156, 22)
        Me.FileSave.Text = "??"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(153, 6)
        '
        'FileLogOut
        '
        Me.FileLogOut.Image = Global.SandiBox.My.Resources.Resources.cancel
        Me.FileLogOut.Name = "FileLogOut"
        Me.FileLogOut.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
                    Or System.Windows.Forms.Keys.L), System.Windows.Forms.Keys)
        Me.FileLogOut.Size = New System.Drawing.Size(156, 22)
        Me.FileLogOut.Text = "??"
        '
        'OperationMenu
        '
        Me.OperationMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OperationBackUp, Me.OperationImport, Me.ToolStripSeparator5, Me.OperationDelete, Me.OperationDeleteAll})
        Me.OperationMenu.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.OperationMenu.Name = "OperationMenu"
        Me.OperationMenu.Size = New System.Drawing.Size(29, 20)
        Me.OperationMenu.Text = "??"
        '
        'OperationBackUp
        '
        Me.OperationBackUp.Image = Global.SandiBox.My.Resources.Resources.storage
        Me.OperationBackUp.Name = "OperationBackUp"
        Me.OperationBackUp.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.B), System.Windows.Forms.Keys)
        Me.OperationBackUp.Size = New System.Drawing.Size(125, 22)
        Me.OperationBackUp.Text = "??"
        '
        'OperationImport
        '
        Me.OperationImport.Image = Global.SandiBox.My.Resources.Resources.reload
        Me.OperationImport.Name = "OperationImport"
        Me.OperationImport.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.I), System.Windows.Forms.Keys)
        Me.OperationImport.Size = New System.Drawing.Size(125, 22)
        Me.OperationImport.Text = "??"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(122, 6)
        '
        'OperationDelete
        '
        Me.OperationDelete.Image = Global.SandiBox.My.Resources.Resources.delete
        Me.OperationDelete.Name = "OperationDelete"
        Me.OperationDelete.ShortcutKeys = System.Windows.Forms.Keys.Delete
        Me.OperationDelete.Size = New System.Drawing.Size(125, 22)
        Me.OperationDelete.Text = "??"
        '
        'OperationDeleteAll
        '
        Me.OperationDeleteAll.Image = Global.SandiBox.My.Resources.Resources.close
        Me.OperationDeleteAll.Name = "OperationDeleteAll"
        Me.OperationDeleteAll.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.R), System.Windows.Forms.Keys)
        Me.OperationDeleteAll.Size = New System.Drawing.Size(125, 22)
        Me.OperationDeleteAll.Text = "??"
        '
        'HelpMenu
        '
        Me.HelpMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.HelpMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HelpReadMe, Me.HelpAbout})
        Me.HelpMenu.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.HelpMenu.Name = "HelpMenu"
        Me.HelpMenu.Size = New System.Drawing.Size(29, 20)
        Me.HelpMenu.Text = "??"
        '
        'HelpReadMe
        '
        Me.HelpReadMe.Image = Global.SandiBox.My.Resources.Resources.attachment
        Me.HelpReadMe.Name = "HelpReadMe"
        Me.HelpReadMe.Size = New System.Drawing.Size(152, 22)
        Me.HelpReadMe.Text = "??"
        '
        'HelpAbout
        '
        Me.HelpAbout.Image = Global.SandiBox.My.Resources.Resources.info
        Me.HelpAbout.Name = "HelpAbout"
        Me.HelpAbout.Size = New System.Drawing.Size(152, 22)
        Me.HelpAbout.Text = "??"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(55, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.StatusStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lbtips, Me.lbhelp})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 528)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(753, 22)
        Me.StatusStrip1.TabIndex = 2
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'lbtips
        '
        Me.lbtips.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbtips.ForeColor = System.Drawing.Color.Yellow
        Me.lbtips.Image = Global.SandiBox.My.Resources.Resources.help
        Me.lbtips.Name = "lbtips"
        Me.lbtips.Size = New System.Drawing.Size(36, 17)
        Me.lbtips.Text = "??:"
        '
        'lbhelp
        '
        Me.lbhelp.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbhelp.Name = "lbhelp"
        Me.lbhelp.Size = New System.Drawing.Size(12, 17)
        Me.lbhelp.Text = "-"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None
        Me.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(95, Byte), Integer), CType(CType(110, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle1.Padding = New System.Windows.Forms.Padding(5)
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.pLabel, Me.pCategory, Me.pUser, Me.pEmail, Me.pPhone, Me.pPassword, Me.pRecovery, Me.pNotes})
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView1.Location = New System.Drawing.Point(0, 63)
        Me.DataGridView1.MultiSelect = False
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(95, Byte), Integer), CType(CType(110, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.RowHeadersVisible = False
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.Padding = New System.Windows.Forms.Padding(10)
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.PaleGreen
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.DataGridView1.RowsDefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(753, 465)
        Me.DataGridView1.TabIndex = 3
        '
        'pLabel
        '
        Me.pLabel.HeaderText = "??"
        Me.pLabel.Name = "pLabel"
        Me.pLabel.ReadOnly = True
        '
        'pCategory
        '
        Me.pCategory.HeaderText = "??"
        Me.pCategory.Name = "pCategory"
        Me.pCategory.ReadOnly = True
        '
        'pUser
        '
        Me.pUser.HeaderText = "??"
        Me.pUser.Name = "pUser"
        Me.pUser.ReadOnly = True
        '
        'pEmail
        '
        Me.pEmail.HeaderText = "??"
        Me.pEmail.Name = "pEmail"
        Me.pEmail.ReadOnly = True
        '
        'pPhone
        '
        Me.pPhone.HeaderText = "??"
        Me.pPhone.Name = "pPhone"
        Me.pPhone.ReadOnly = True
        '
        'pPassword
        '
        Me.pPassword.HeaderText = "??"
        Me.pPassword.Name = "pPassword"
        Me.pPassword.ReadOnly = True
        '
        'pRecovery
        '
        Me.pRecovery.HeaderText = "??"
        Me.pRecovery.Name = "pRecovery"
        Me.pRecovery.ReadOnly = True
        '
        'pNotes
        '
        Me.pNotes.HeaderText = "??"
        Me.pNotes.Name = "pNotes"
        Me.pNotes.ReadOnly = True
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackColor = System.Drawing.Color.White
        Me.ToolStrip1.GripMargin = New System.Windows.Forms.Padding(10)
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ButtonAddNew, Me.ButtonEdit, Me.ToolStripSeparator1, Me.ButtonBackup, Me.ButtonRestore, Me.ToolStripSeparator2, Me.ButtonDelete, Me.ButtonDeleteAll})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.ToolStrip1.Size = New System.Drawing.Size(753, 39)
        Me.ToolStrip1.TabIndex = 4
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ButtonAddNew
        '
        Me.ButtonAddNew.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ButtonAddNew.Image = Global.SandiBox.My.Resources.Resources.add
        Me.ButtonAddNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ButtonAddNew.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ButtonAddNew.Name = "ButtonAddNew"
        Me.ButtonAddNew.Size = New System.Drawing.Size(53, 36)
        Me.ButtonAddNew.Text = "??"
        '
        'ButtonEdit
        '
        Me.ButtonEdit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ButtonEdit.Image = Global.SandiBox.My.Resources.Resources.edit
        Me.ButtonEdit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ButtonEdit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ButtonEdit.Name = "ButtonEdit"
        Me.ButtonEdit.Size = New System.Drawing.Size(53, 36)
        Me.ButtonEdit.Text = "??"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 39)
        '
        'ButtonBackup
        '
        Me.ButtonBackup.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ButtonBackup.Image = Global.SandiBox.My.Resources.Resources.storage
        Me.ButtonBackup.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ButtonBackup.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ButtonBackup.Name = "ButtonBackup"
        Me.ButtonBackup.Size = New System.Drawing.Size(53, 36)
        Me.ButtonBackup.Text = "??"
        '
        'ButtonRestore
        '
        Me.ButtonRestore.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ButtonRestore.Image = Global.SandiBox.My.Resources.Resources.reload
        Me.ButtonRestore.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ButtonRestore.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ButtonRestore.Name = "ButtonRestore"
        Me.ButtonRestore.Size = New System.Drawing.Size(53, 36)
        Me.ButtonRestore.Text = "??"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 39)
        '
        'ButtonDelete
        '
        Me.ButtonDelete.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ButtonDelete.Image = Global.SandiBox.My.Resources.Resources.delete
        Me.ButtonDelete.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ButtonDelete.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ButtonDelete.Name = "ButtonDelete"
        Me.ButtonDelete.Size = New System.Drawing.Size(53, 36)
        Me.ButtonDelete.Text = "??"
        '
        'ButtonDeleteAll
        '
        Me.ButtonDeleteAll.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ButtonDeleteAll.Image = Global.SandiBox.My.Resources.Resources.close
        Me.ButtonDeleteAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ButtonDeleteAll.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ButtonDeleteAll.Name = "ButtonDeleteAll"
        Me.ButtonDeleteAll.Size = New System.Drawing.Size(53, 36)
        Me.ButtonDeleteAll.Text = "??"
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Label1.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(62, 188)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(599, 84)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Label1"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(12, 107)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(729, 407)
        Me.Panel1.TabIndex = 6
        Me.Panel1.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.PictureBox1.Image = Global.SandiBox.My.Resources.Resources.add
        Me.PictureBox1.Location = New System.Drawing.Point(346, 153)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(32, 32)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 6
        Me.PictureBox1.TabStop = False
        '
        'TimerHelp
        '
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContextEdit, Me.ContextDelete})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(125, 48)
        '
        'ContextEdit
        '
        Me.ContextEdit.Image = Global.SandiBox.My.Resources.Resources.edit
        Me.ContextEdit.Name = "ContextEdit"
        Me.ContextEdit.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.E), System.Windows.Forms.Keys)
        Me.ContextEdit.Size = New System.Drawing.Size(124, 22)
        Me.ContextEdit.Text = "??"
        '
        'ContextDelete
        '
        Me.ContextDelete.Image = Global.SandiBox.My.Resources.Resources.delete
        Me.ContextDelete.Name = "ContextDelete"
        Me.ContextDelete.ShortcutKeys = System.Windows.Forms.Keys.Delete
        Me.ContextDelete.Size = New System.Drawing.Size(124, 22)
        Me.ContextDelete.Text = "??"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(753, 550)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = " "
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileAddNew As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents FileSave As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OperationMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OperationDelete As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OperationDeleteAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ButtonAddNew As System.Windows.Forms.ToolStripButton
    Friend WithEvents ButtonEdit As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ButtonBackup As System.Windows.Forms.ToolStripButton
    Friend WithEvents ButtonRestore As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ButtonDelete As System.Windows.Forms.ToolStripButton
    Friend WithEvents ButtonDeleteAll As System.Windows.Forms.ToolStripButton
    Friend WithEvents pLabel As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents pCategory As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents pUser As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents pEmail As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents pPhone As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents pPassword As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents pRecovery As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents pNotes As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents FileLogOut As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OperationBackUp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OperationImport As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents lbtips As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lbhelp As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents TimerHelp As System.Windows.Forms.Timer
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ContextEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContextDelete As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpReadMe As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpAbout As System.Windows.Forms.ToolStripMenuItem
End Class
