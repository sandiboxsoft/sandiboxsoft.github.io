﻿Imports System.Runtime.InteropServices
Imports System.Diagnostics

Module WindowsKeyBlocker

    Private Const WH_KEYBOARD_LL As Integer = 13
    Private Const WM_KEYDOWN As Integer = &H100
    Private Const WM_SYSKEYDOWN As Integer = &H104

    Private hookID As IntPtr = IntPtr.Zero
    Private Delegate Function LowLevelKeyboardProc(ByVal nCode As Integer, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As IntPtr
    Private proc As LowLevelKeyboardProc = AddressOf HookCallback

    Public Sub MulaiBlokirWindowsKey()
        hookID = SetHook(proc)
    End Sub

    Public Sub StopBlokirWindowsKey()
        UnhookWindowsHookEx(hookID)
    End Sub

    Private Function SetHook(ByVal proc As LowLevelKeyboardProc) As IntPtr
        Using curProcess As Process = Process.GetCurrentProcess()
            Using curModule As ProcessModule = curProcess.MainModule
                Return SetWindowsHookEx(WH_KEYBOARD_LL, proc, GetModuleHandle(curModule.ModuleName), 0)
            End Using
        End Using
    End Function

    Private Function HookCallback(ByVal nCode As Integer, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As IntPtr
        If nCode >= 0 AndAlso (wParam = CType(WM_KEYDOWN, IntPtr) OrElse wParam = CType(WM_SYSKEYDOWN, IntPtr)) Then
            Dim vkCode As Integer = Marshal.ReadInt32(lParam)

            ' Blokir tombol Windows kiri dan kanan
            If vkCode = 91 OrElse vkCode = 92 Then ' 91 = LWin, 92 = RWin
                Return CType(1, IntPtr) ' Blokir
            End If
        End If
        Return CallNextHookEx(hookID, nCode, wParam, lParam)
    End Function

    ' API deklarasi
    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)>
    Private Function SetWindowsHookEx(ByVal idHook As Integer, ByVal lpfn As LowLevelKeyboardProc,
                                      ByVal hMod As IntPtr, ByVal dwThreadId As UInteger) As IntPtr
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)>
    Private Function UnhookWindowsHookEx(ByVal hhk As IntPtr) As Boolean
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)>
    Private Function CallNextHookEx(ByVal hhk As IntPtr, ByVal nCode As Integer,
                                    ByVal wParam As IntPtr, ByVal lParam As IntPtr) As IntPtr
    End Function

    <DllImport("kernel32.dll", CharSet:=CharSet.Auto, SetLastError:=True)>
    Private Function GetModuleHandle(ByVal lpModuleName As String) As IntPtr
    End Function

End Module
