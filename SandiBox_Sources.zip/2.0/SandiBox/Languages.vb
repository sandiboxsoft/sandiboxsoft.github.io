﻿Imports System.IO

Module Languages
    Public langen As String = "language.dll"
    Public createpassword As String
    Public creatnewpassword As String
    Public loginhead As String
    Public loginsandi As String
    Public autologout As String
    Public wrongpass As String
    Public buttonedit As String
    Public edithead As String
    Public passwordcreate As String
    Public passwordenter As String
    Public passwordcheck As String
    Public passwordbutton As String
    Public infonodata As String
    Public infodeleteall As String
    Public infodelete As String
    Public infoedit As String
    Public infoaddnew As String
    Public infopenting As String
    Public infoduplikat As String
    Public infonodatafound As String
    Public infonosingeldatafound As String
    Public infodatabad As String
    Public infoerrorload As String
    Public infodataerror As String
    Public infonopassword As String
    Public infonewpassword1 As String
    Public infonewpassword2 As String
    Public infonewpassword3 As String
    Public infologout As String
    Public inforesetpassword1 As String
    Public inforesetpassword2 As String
    Public infonodatagrid As String
    Public infohelp1 As String
    Public infohelp2 As String
    Public infohelp3 As String
    Public backupdata As String
    Public importdata As String
    Public registersuccess As String
    Public kategoricombo() As String
    Public impor1 As String
    Public impor2 As String
    Public backupnodata As String
    Public infologgedout As String
    Public infooffline As String
    Public infosending As String
    Public infosent As String
    Public infobacksuccess As String
    Public infobackfailed As String
    Public infouploadftp As String
    Private Function AmbilIsi(ByVal baris As String) As String
        Dim pisah() As String = baris.Split("="c)
        If pisah.Length > 1 Then
            Return pisah(1).Trim()
        End If
        Return ""
    End Function
    Sub getcategories()
        Dim filePath As String = langen ' Ganti jika nama filenya berbeda
        If File.Exists(filePath) Then
            Dim allLines() As String = File.ReadAllLines(filePath)
            Dim startIndex As Integer = -1
            Dim endIndex As Integer = -1

            ' Cari baris "category select" dan "end selected"
            For i As Integer = 0 To allLines.Length - 1
                If allLines(i).Trim.ToLower() = "category select" Then
                    startIndex = i + 1
                ElseIf allLines(i).Trim.ToLower() = "end selected" Then
                    endIndex = i - 1
                    Exit For
                End If
            Next

            ' Jika ditemukan, ambil datanya ke dalam array
            If startIndex <> -1 AndAlso endIndex >= startIndex Then
                Dim listKategori As New List(Of String)
                For i As Integer = startIndex To endIndex
                    Dim line As String = allLines(i).Trim()
                    If line <> "" Then
                        listKategori.Add(line)
                    End If
                Next
                kategoricombo = listKategori.ToArray()
            End If
        Else
            ' MsgBox("File tidak ditemukan: " & filePath)
        End If
    End Sub
    Public Sub Lang_Settings()
        If Not File.Exists(langen) Then Exit Sub

        Dim lines() As String = File.ReadAllLines(langen)
        getcategories()
        If lines.Length > 0 Then Form1.LabelHead.Text = AmbilIsi(lines(0))
        If lines.Length > 1 Then Form1.ButtonLogin.Text = AmbilIsi(lines(1))
        If lines.Length > 2 Then createpassword = AmbilIsi(lines(2))
        If lines.Length > 3 Then creatnewpassword = AmbilIsi(lines(3))
        If lines.Length > 4 Then loginhead = AmbilIsi(lines(4))
        If lines.Length > 5 Then loginsandi = AmbilIsi(lines(5))
        If lines.Length > 6 Then autologout = AmbilIsi(lines(6))
        If lines.Length > 7 Then wrongpass = AmbilIsi(lines(7))
        If lines.Length > 8 Then Form2.Text = AmbilIsi(lines(8))
        If lines.Length > 9 Then Form2.FileMenu.Text = AmbilIsi(lines(9))
        If lines.Length > 10 Then Form2.FileAddNew.Text = AmbilIsi(lines(10))
        If lines.Length > 11 Then Form2.FileEdit.Text = AmbilIsi(lines(11))
        If lines.Length > 12 Then Form2.FileSave.Text = AmbilIsi(lines(12))
        If lines.Length > 13 Then Form2.FileLogOut.Text = AmbilIsi(lines(13))
        If lines.Length > 14 Then Form2.OperationMenu.Text = AmbilIsi(lines(14))
        If lines.Length > 15 Then Form2.OperationBackUp.Text = AmbilIsi(lines(15))
        If lines.Length > 16 Then Form2.OperationImport.Text = AmbilIsi(lines(16))
        If lines.Length > 17 Then Form2.OperationDelete.Text = AmbilIsi(lines(17))
        If lines.Length > 18 Then Form2.OperationDeleteAll.Text = AmbilIsi(lines(18))
        If lines.Length > 19 Then Form2.HelpMenu.Text = AmbilIsi(lines(19))
        If lines.Length > 20 Then Form2.HelpAbout.Text = AmbilIsi(lines(20))
        If lines.Length > 21 Then Form2.ButtonAddNew.Text = AmbilIsi(lines(21))
        If lines.Length > 22 Then Form2.ButtonEdit.Text = AmbilIsi(lines(22))
        If lines.Length > 23 Then Form2.ButtonBackup.Text = AmbilIsi(lines(23))
        If lines.Length > 24 Then Form2.ButtonRestore.Text = AmbilIsi(lines(24))
        If lines.Length > 25 Then Form2.ButtonDelete.Text = AmbilIsi(lines(25))
        If lines.Length > 26 Then Form2.ButtonDeleteAll.Text = AmbilIsi(lines(26))
        If lines.Length > 27 Then Form2.DataGridView1.Columns(0).HeaderText = AmbilIsi(lines(27))
        If lines.Length > 28 Then Form2.DataGridView1.Columns(1).HeaderText = AmbilIsi(lines(28))
        If lines.Length > 29 Then Form2.DataGridView1.Columns(2).HeaderText = AmbilIsi(lines(29))
        If lines.Length > 30 Then Form2.DataGridView1.Columns(3).HeaderText = AmbilIsi(lines(30))
        If lines.Length > 31 Then Form2.DataGridView1.Columns(4).HeaderText = AmbilIsi(lines(31))
        If lines.Length > 32 Then Form2.DataGridView1.Columns(5).HeaderText = AmbilIsi(lines(32))
        If lines.Length > 33 Then Form2.DataGridView1.Columns(6).HeaderText = AmbilIsi(lines(33))
        If lines.Length > 34 Then Form2.DataGridView1.Columns(7).HeaderText = AmbilIsi(lines(34))
        If lines.Length > 35 Then frmAddNew.LabelHead.Text = AmbilIsi(lines(35))
        If lines.Length > 36 Then frmAddNew.LabelLabel.Text = AmbilIsi(lines(36))
        If lines.Length > 37 Then frmAddNew.LabelCategory.Text = AmbilIsi(lines(37))
        If lines.Length > 38 Then frmAddNew.LabelUsername.Text = AmbilIsi(lines(38))
        If lines.Length > 39 Then frmAddNew.LabelEmail.Text = AmbilIsi(lines(39))
        If lines.Length > 40 Then frmAddNew.LabelPhone.Text = AmbilIsi(lines(40))
        If lines.Length > 41 Then frmAddNew.LabelPassword.Text = AmbilIsi(lines(41))
        If lines.Length > 42 Then frmAddNew.LabelRecovery.Text = AmbilIsi(lines(42))
        If lines.Length > 43 Then frmAddNew.LabelNotes.Text = AmbilIsi(lines(43))
        If lines.Length > 44 Then frmAddNew.ButtonAdd.Text = AmbilIsi(lines(44))
        If lines.Length > 45 Then frmAddNew.ButtonClose.Text = AmbilIsi(lines(45))
        If lines.Length > 46 Then buttonedit = AmbilIsi(lines(46))
        If lines.Length > 47 Then edithead = AmbilIsi(lines(47))
        If lines.Length > 48 Then infonodata = AmbilIsi(lines(48))
        If lines.Length > 49 Then infodeleteall = AmbilIsi(lines(49))
        If lines.Length > 50 Then infodelete = AmbilIsi(lines(50))
        If lines.Length > 51 Then infoedit = AmbilIsi(lines(51))
        If lines.Length > 52 Then infoaddnew = AmbilIsi(lines(52))
        If lines.Length > 53 Then infopenting = AmbilIsi(lines(53))
        If lines.Length > 54 Then infoduplikat = AmbilIsi(lines(54))
        If lines.Length > 55 Then infonodatafound = AmbilIsi(lines(55))
        If lines.Length > 56 Then infonosingeldatafound = AmbilIsi(lines(56))
        If lines.Length > 57 Then infodatabad = AmbilIsi(lines(57))
        If lines.Length > 58 Then infoerrorload = AmbilIsi(lines(58))
        If lines.Length > 59 Then infodataerror = AmbilIsi(lines(59))
        If lines.Length > 60 Then infonopassword = AmbilIsi(lines(60))
        If lines.Length > 61 Then infonewpassword1 = AmbilIsi(lines(61))
        If lines.Length > 62 Then infonewpassword2 = AmbilIsi(lines(62))
        If lines.Length > 63 Then infonewpassword3 = AmbilIsi(lines(63))
        If lines.Length > 64 Then infologout = AmbilIsi(lines(64))
        If lines.Length > 65 Then inforesetpassword1 = AmbilIsi(lines(65))
        If lines.Length > 66 Then inforesetpassword2 = AmbilIsi(lines(66))
        If lines.Length > 67 Then infonodatagrid = AmbilIsi(lines(67))
        If lines.Length > 68 Then infohelp1 = AmbilIsi(lines(68))
        If lines.Length > 69 Then infohelp2 = AmbilIsi(lines(69))
        If lines.Length > 70 Then infohelp3 = AmbilIsi(lines(70))
        If lines.Length > 71 Then importdata = AmbilIsi(lines(71))
        If lines.Length > 72 Then backupdata = AmbilIsi(lines(72))
        If lines.Length > 73 Then Form2.ContextDelete.Text = AmbilIsi(lines(73))
        If lines.Length > 74 Then Form2.ContextEdit.Text = AmbilIsi(lines(74))
        If lines.Length > 75 Then registersuccess = AmbilIsi(lines(75))
        If lines.Length > 76 Then impor1 = AmbilIsi(lines(76))
        If lines.Length > 77 Then impor2 = AmbilIsi(lines(77))
        If lines.Length > 78 Then backupnodata = AmbilIsi(lines(78))
        If lines.Length > 79 Then Form2.HelpReadMe.Text = AmbilIsi(lines(79))
        If lines.Length > 80 Then frmAbout.lbauthor.Text = AmbilIsi(lines(80))
        If lines.Length > 81 Then frmAbout.lblicense.Text = AmbilIsi(lines(81))
        If lines.Length > 82 Then frmAbout.lbtagging.Text = AmbilIsi(lines(82))
        If lines.Length > 83 Then infologgedout = AmbilIsi(lines(83))
        If lines.Length > 84 Then frmAbout.lbcopy.Text = AmbilIsi(lines(84))
        If lines.Length > 85 Then frmAbout.lbsendfeedback.Text = AmbilIsi(lines(85))
        If lines.Length > 86 Then frmAbout.ButtonSend.Text = AmbilIsi(lines(86))
        If lines.Length > 87 Then infooffline = AmbilIsi(lines(87))
        If lines.Length > 88 Then infosending = AmbilIsi(lines(88))
        If lines.Length > 89 Then frmAbout.lbname.Text = AmbilIsi(lines(89))
        If lines.Length > 90 Then frmAbout.lbmessage.Text = AmbilIsi(lines(90))
        If lines.Length > 91 Then infosent = AmbilIsi(lines(91))
        If lines.Length > 92 Then frmBackUp.Text = AmbilIsi(lines(92))
        If lines.Length > 93 Then frmBackUp.CheckBox1.Text = AmbilIsi(lines(93))
        If lines.Length > 94 Then frmBackUp.CheckBox2.Text = AmbilIsi(lines(94))
        If lines.Length > 95 Then frmBackUp.lburl.Text = AmbilIsi(lines(95))
        If lines.Length > 96 Then frmBackUp.lbusername.Text = AmbilIsi(lines(96))
        If lines.Length > 97 Then frmBackUp.lbpassword.Text = AmbilIsi(lines(97))
        If lines.Length > 98 Then frmBackUp.Button1.Text = AmbilIsi(lines(98))
        If lines.Length > 99 Then frmBackUp.ButtonLocal.Text = AmbilIsi(lines(99))
        If lines.Length > 100 Then frmBackUp.CheckBox3.Text = AmbilIsi(lines(100))
        If lines.Length > 101 Then infobacksuccess = AmbilIsi(lines(101))
        If lines.Length > 102 Then infobackfailed = AmbilIsi(lines(102))
        If lines.Length > 103 Then infouploadftp = AmbilIsi(lines(103))
        Form2.Label1.Text = infonodatagrid
        Form2.lbtips.Text = infohelp1
        Form2.lbhelp.Text = infohelp2
    End Sub
End Module
