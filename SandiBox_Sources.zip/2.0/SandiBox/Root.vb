﻿Imports System.Text
Imports System.Security.Cryptography

Module Root
    Dim KEY As String = "Gamemetalslug@1ArixGantengAriAnakLombokDanCintaIndoesia100%dansukamembacawikipediasambilmakanlalapan"

    Public Function Encrypt(ByVal text As String) As String
        Dim buffer As Byte() = Encoding.UTF8.GetBytes(text)
        Dim md5 As New MD5CryptoServiceProvider()
        Dim tripleDes As New TripleDESCryptoServiceProvider()
        tripleDes.Key = md5.ComputeHash(Encoding.UTF8.GetBytes(KEY))
        tripleDes.Mode = CipherMode.ECB
        Dim transform = tripleDes.CreateEncryptor()
        Return Convert.ToBase64String(transform.TransformFinalBlock(buffer, 0, buffer.Length))
    End Function

    Public Function Decrypt(ByVal text As String) As String
        Dim buffer As Byte() = Convert.FromBase64String(text)
        Dim md5 As New MD5CryptoServiceProvider()
        Dim tripleDes As New TripleDESCryptoServiceProvider()
        tripleDes.Key = md5.ComputeHash(Encoding.UTF8.GetBytes(KEY))
        tripleDes.Mode = CipherMode.ECB
        Dim transform = tripleDes.CreateDecryptor()
        Return Encoding.UTF8.GetString(transform.TransformFinalBlock(buffer, 0, buffer.Length))
    End Function

End Module