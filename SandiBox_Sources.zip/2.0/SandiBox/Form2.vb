﻿Imports System.Xml
Imports System.IO
Imports System.Threading

Public Class Form2
    Public editMode As Boolean = False
    Public editRowIndex As Integer = -1
    Public deleteall As Boolean = False
    Dim dataPath As String = "base.dll"
    Dim pinnedList As New List(Of String)
    Dim teksList() As String
    Dim index As Integer = 0
    Public timeout As Boolean = False
    Protected Overrides ReadOnly Property CreateParams() As CreateParams
        Get
            Dim cp As CreateParams = MyBase.CreateParams
            Const CS_NOCLOSE As Integer = &H200
            cp.ClassStyle = cp.ClassStyle Or CS_NOCLOSE
            Return cp
        End Get
    End Property
    Sub cekdata()
        If DataGridView1.Rows.Count = 0 Then
            Panel1.Visible = True
        Else
            Panel1.Visible = False
        End If
    End Sub
    Private Sub LoadData()
        Dim t As New Thread(AddressOf LoadDataInThread)
        t.IsBackground = True
        t.Start()
    End Sub

    Private Sub LoadDataInThread()
        Try
            If Not File.Exists("base.dll") Then Exit Sub

            Dim doc As New XmlDocument()
            doc.Load("base.dll")

            Dim rowList As New List(Of Object())

            For Each entry As XmlNode In doc.DocumentElement.ChildNodes
                Try
                    Dim label = GetXmlValue(entry, "Label")
                    Dim category = Crypto.Decrypt(GetXmlValue(entry, "Category"))
                    Dim username = Crypto.Decrypt(GetXmlValue(entry, "Username"))
                    Dim email = Crypto.Decrypt(GetXmlValue(entry, "E-Mail"))
                    Dim phone = Crypto.Decrypt(GetXmlValue(entry, "Phone"))
                    Dim password = Crypto.Decrypt(GetXmlValue(entry, "Password"))
                    Dim recovery = Crypto.Decrypt(GetXmlValue(entry, "Recovery"))
                    Dim notes = Crypto.Decrypt(GetXmlValue(entry, "Notes"))

                    rowList.Add(New Object() {label, category, username, email, phone, password, recovery, notes})
                Catch ex As Exception
                    ' Skip data error
                End Try
            Next

            ' Update UI (DataGridView1) dari UI thread
            If DataGridView1.InvokeRequired Then
                DataGridView1.Invoke(New MethodInvoker(Sub()
                                                           DataGridView1.Rows.Clear()
                                                           For Each rowData In rowList
                                                               DataGridView1.Rows.Add(rowData)
                                                           Next
                                                           cekdata()
                                                       End Sub))
            End If

        Catch ex As XmlException
            MsgBox(infodatabad, MsgBoxStyle.Critical)
            File.Delete(dataPath)
            If Me.InvokeRequired Then
                Me.Invoke(New MethodInvoker(AddressOf ResetFormState))
            Else
                ResetFormState()
            End If
        Catch ex As Exception
            MsgBox(infoerrorload, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub ResetFormState()
        Lang_Settings()
        Form1.Text = creatnewpassword
        Form1.ButtonLogin.Text = createpassword
        Form1.ButtonLogin.Width = 141
        Form1.ButtonLogin.Location = New Point(138, 87)
        Form1.LabelHead.Text = creatnewpassword
        Form1.lblStatus.Text = creatnewpassword
        Form1.lblStatus.ForeColor = Color.Blue
    End Sub

    Private Function GetXmlValue(ByVal parent As XmlNode, ByVal name As String) As String
        Try
            Dim node = parent(name)
            If node IsNot Nothing Then
                Return node.InnerText
            Else
                Return ""
            End If
        Catch
            Return ""
        End Try
    End Function
    Private Sub LoadRestore()
        DataGridView1.Rows.Clear()
        If Not File.Exists("base.dll") Then Exit Sub

        Dim doc As New XmlDocument()
        doc.Load("base.dll")

        For Each entry As XmlNode In doc.DocumentElement.ChildNodes
            DataGridView1.Rows.Add(
                entry("Label").InnerText,
                entry("Category").InnerText,
                entry("Username").InnerText,
                entry("E-Mail").InnerText,
                entry("Phone").InnerText,
                entry("Password").InnerText,
                entry("Recovery").InnerText,
                entry("Notes").InnerText
            )
        Next
        cekdata()
    End Sub
    Public Sub SaveBackUp()
        Dim doc As New XmlDocument()
        Dim root = doc.CreateElement("Entries")
        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.IsNewRow Then Continue For

            Dim entry = doc.CreateElement("Entry")
            entry.AppendChild(doc.CreateElement("Label")).InnerText = row.Cells(0).Value
            entry.AppendChild(doc.CreateElement("Category")).InnerText = row.Cells(1).Value
            entry.AppendChild(doc.CreateElement("Username")).InnerText = row.Cells(2).Value
            entry.AppendChild(doc.CreateElement("E-Mail")).InnerText = row.Cells(3).Value
            entry.AppendChild(doc.CreateElement("Phone")).InnerText = row.Cells(4).Value
            entry.AppendChild(doc.CreateElement("Password")).InnerText = row.Cells(5).Value
            entry.AppendChild(doc.CreateElement("Recovery")).InnerText = row.Cells(6).Value
            entry.AppendChild(doc.CreateElement("Notes")).InnerText = row.Cells(7).Value
            root.AppendChild(entry)
        Next

        doc.AppendChild(root)
        doc.Save("base.dll")
    End Sub
    Public Sub SaveData()
        Dim doc As New XmlDocument()
        Dim root = doc.CreateElement("Entries")
        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.IsNewRow Then Continue For

            Dim entry = doc.CreateElement("Entry")
            entry.AppendChild(doc.CreateElement("Label")).InnerText = row.Cells(0).Value
            entry.AppendChild(doc.CreateElement("Category")).InnerText = Crypto.Encrypt(row.Cells(1).Value)
            entry.AppendChild(doc.CreateElement("Username")).InnerText = Crypto.Encrypt(row.Cells(2).Value)
            entry.AppendChild(doc.CreateElement("E-Mail")).InnerText = Crypto.Encrypt(row.Cells(3).Value)
            entry.AppendChild(doc.CreateElement("Phone")).InnerText = Crypto.Encrypt(row.Cells(4).Value)
            entry.AppendChild(doc.CreateElement("Password")).InnerText = Crypto.Encrypt(row.Cells(5).Value)
            entry.AppendChild(doc.CreateElement("Recovery")).InnerText = Crypto.Encrypt(row.Cells(6).Value)
            entry.AppendChild(doc.CreateElement("Notes")).InnerText = Crypto.Encrypt(row.Cells(7).Value)
            root.AppendChild(entry)
        Next

        doc.AppendChild(root)
        doc.Save("base.dll")
    End Sub
  
    Private Sub Form2_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If timeout Then
            StopBlokirWindowsKey()
            SaveData()

            Form1.Show()
            Me.Hide()
        Else
            If MsgBox(infologout, MessageBoxButtons.OKCancel) = DialogResult.OK Then
                StopBlokirWindowsKey()
                SaveData()
                Form1.lblStatus.Text = infologgedout
                Form1.lblStatus.ForeColor = Color.Orange
                Form1.Show()
                Me.Hide()
            Else
                e.Cancel = True
            End If
        End If
    End Sub
   
    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Icon = My.Resources.favicon
        cekdata()
        Lang_Settings()
        MulaiBlokirWindowsKey()
        LoadData()
        teksList = New String() {infohelp2, infohelp3}
        TimerHelp.Interval = 5000
        TimerHelp.Start()
    End Sub

    Private Sub ButtonAddNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonAddNew.Click
        frmAddNew.Show()
    End Sub

    Private Sub ButtonEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonEdit.Click
        If DataGridView1.SelectedRows.Count = 0 Then
            MsgBox(infonodata, vbExclamation)
            Exit Sub
        End If
        Dim row As DataGridViewRow = DataGridView1.SelectedRows(0)
        If MsgBox(infoedit & " '" & row.Cells(0).Value.ToString() & " ?", MessageBoxButtons.YesNo) = DialogResult.Yes Then
            frmAddNew.TextBox1.Text = row.Cells(0).Value.ToString()
            frmAddNew.ComboBox1.Text = row.Cells(1).Value.ToString()
            frmAddNew.TextBox2.Text = row.Cells(2).Value.ToString()
            frmAddNew.TextBox3.Text = row.Cells(3).Value.ToString()
            frmAddNew.TextBox4.Text = row.Cells(4).Value.ToString()
            frmAddNew.TextBox5.Text = row.Cells(5).Value.ToString()
            frmAddNew.TextBox6.Text = row.Cells(6).Value.ToString()
            frmAddNew.TextBox7.Text = row.Cells(7).Value.ToString()
            frmAddNew.Text = edithead & " " & row.Cells(0).Value.ToString()
            frmAddNew.lbinfo.Text = "Edit"
            frmAddNew.Show()
        Else
            '
        End If

    End Sub

    Private Sub ButtonDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonDelete.Click
        If DataGridView1.SelectedRows.Count = 0 Then
            MsgBox(infonodata, vbExclamation)
            Exit Sub
        End If
        Dim rows As DataGridViewRow = DataGridView1.SelectedRows(0)
        If DataGridView1.SelectedRows.Count > 0 Then
            If MsgBox(infodelete & " " & rows.Cells(0).Value.ToString, MessageBoxButtons.YesNo) = DialogResult.Yes Then
                For Each row As DataGridViewRow In DataGridView1.SelectedRows
                    If Not row.IsNewRow Then
                        DataGridView1.Rows.Remove(row)
                    End If
                Next
                SaveData()
                cekdata()
            End If
        Else
            MsgBox(infonodata, vbExclamation)
        End If
    End Sub

    Private Sub ButtonDeleteAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonDeleteAll.Click
        If DataGridView1.Rows.Count = 0 Then
            MsgBox(infonodata, vbExclamation)
            Exit Sub
        End If

        If MsgBox(infodeleteall, MessageBoxButtons.YesNo) = DialogResult.Yes Then
            DataGridView1.Rows.Clear()
            SaveData()
            cekdata()
        End If
    End Sub
    Sub backdatalocal()
        If DataGridView1.Rows.Count = 0 Then
            MsgBox(backupnodata, vbExclamation)
            Exit Sub
        End If
        SaveBackUp()
        Dim dlg As New SaveFileDialog()
        dlg.Title = backupdata
        dlg.Filter = "SandiBox |*.sb"
        If dlg.ShowDialog() = DialogResult.OK Then
            File.Copy("base.dll", dlg.FileName, True)
            backrest.EnkripsiFileLangsung(dlg.FileName, "Gamemetalslug@1")
        End If
    End Sub
    Private Sub ButtonBackup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonBackup.Click
        frmBackUp.Show()
    End Sub

    Private Sub ButtonRestore_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonRestore.Click
        If DataGridView1.Rows.Count = 0 Then
            Dim dlg As New OpenFileDialog()
            dlg.Title = importdata
            dlg.Filter = "SandiBox |*.sb"
            If dlg.ShowDialog() = DialogResult.OK Then
                File.Copy(dlg.FileName, "base.dll", True)
                backrest.DekripsiFileLangsung(dataPath, "Gamemetalslug@1")
                LoadRestore()
                SaveData()
                cekdata()
            End If
        Else
            Dim pesan As String = impor1 & vbNewLine & vbNewLine & impor2
            Dim hasil As DialogResult = MessageBox.Show(pesan, "", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
            If hasil = DialogResult.Yes Then
                Dim dlg As New OpenFileDialog()
                dlg.Title = importdata
                dlg.Filter = "SandiBox |*.sb"
                If dlg.ShowDialog() = DialogResult.OK Then
                    File.Copy(dlg.FileName, "base.dll", True)
                    backrest.DekripsiFileLangsung(dataPath, "Gamemetalslug@1")
                    LoadRestore()
                    SaveData()
                    cekdata()
                End If
            Else
                ' Batalkan atau keluar
            End If
        End If
        
    End Sub
    Private Sub DataGridView1_CellContentDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentDoubleClick
        If e.RowIndex < 0 Then Exit Sub ' Cegah jika header baris diklik

        If DataGridView1.SelectedRows.Count = 0 Then
            MsgBox(infonodata, MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim row As DataGridViewRow = DataGridView1.SelectedRows(0)

        If MsgBox(infoedit & " '" & row.Cells(0).Value.ToString() & "' ?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            frmAddNew.TextBox1.Text = row.Cells(0).Value.ToString()
            frmAddNew.ComboBox1.Text = row.Cells(1).Value.ToString()
            frmAddNew.TextBox2.Text = row.Cells(2).Value.ToString()
            frmAddNew.TextBox3.Text = row.Cells(3).Value.ToString()
            frmAddNew.TextBox4.Text = row.Cells(4).Value.ToString()
            frmAddNew.TextBox5.Text = row.Cells(5).Value.ToString()
            frmAddNew.TextBox6.Text = row.Cells(6).Value.ToString()
            frmAddNew.TextBox7.Text = row.Cells(7).Value.ToString()
            frmAddNew.Text = edithead & " " & row.Cells(0).Value.ToString()
            frmAddNew.lbinfo.Text = "Edit"
            frmAddNew.Show()
        End If
    End Sub

    Private Sub DataGridView1_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles DataGridView1.CellFormatting
        If (e.ColumnIndex = 5 OrElse e.ColumnIndex = 6) AndAlso e.Value IsNot Nothing Then
            Dim originalLength As Integer = e.Value.ToString().Length
            e.Value = New String("*"c, originalLength)
            e.FormattingApplied = True
        End If
    End Sub

    Private Sub DataGridView1_CellMouseLeave(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellMouseLeave
        ' Kembalikan kursor ke default saat keluar dari DataGridView
        DataGridView1.Cursor = Cursors.Default
    End Sub

    Private Sub DataGridView1_CellMouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseMove
        If e.RowIndex >= 0 Then
            If DataGridView1.Rows(e.RowIndex).Selected Then
                DataGridView1.Cursor = Cursors.Hand
            Else
                DataGridView1.Cursor = Cursors.Default
            End If
        Else
            DataGridView1.Cursor = Cursors.Default
        End If
    End Sub

    Private Sub DataGridView1_RowPrePaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPrePaintEventArgs) Handles DataGridView1.RowPrePaint
        Dim rowIndex As Integer = e.RowIndex
        Dim row As DataGridViewRow = DataGridView1.Rows(rowIndex)

        ' Daftar warna latar belakang bergantian
        Dim warna() As Color = {
            Color.FromArgb(40, 45, 60),
            Color.FromArgb(50, 55, 70),
            Color.FromArgb(60, 65, 80),
            Color.FromArgb(70, 75, 90),
            Color.FromArgb(80, 85, 100),
            Color.FromArgb(90, 95, 110)
        }

        Dim warnaBack As Color = warna(rowIndex Mod warna.Length)
        row.DefaultCellStyle.BackColor = warnaBack

        ' Hitung kecerahan untuk menentukan warna teks
        Dim brightness As Single = warnaBack.GetBrightness()

        If brightness > 0.6 Then
            row.DefaultCellStyle.ForeColor = Color.Black
        Else
            row.DefaultCellStyle.ForeColor = Color.White
        End If

        ' Hilangkan efek seleksi warna default
        row.DefaultCellStyle.SelectionBackColor = warnaBack
        row.DefaultCellStyle.SelectionForeColor = Color.Yellow

        ' Buat font tebal saat terseleksi
        If DataGridView1.Rows(rowIndex).Selected Then
            row.DefaultCellStyle.Font = New Font(DataGridView1.Font, FontStyle.Bold)
        Else
            row.DefaultCellStyle.Font = New Font(DataGridView1.Font, FontStyle.Regular)
        End If
    End Sub

    Private Sub FileLogOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileLogOut.Click
        Me.Close()
    End Sub

    Private Sub FileSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileSave.Click
        SaveData()
    End Sub

    Private Sub FileAddNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileAddNew.Click
        ButtonAddNew.PerformClick()
    End Sub

    Private Sub FileEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileEdit.Click
        ButtonEdit.PerformClick()
    End Sub

   
    Private Sub OperationBackUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OperationBackUp.Click
        ButtonBackup.PerformClick()
    End Sub

    Private Sub OperationImport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OperationImport.Click
        ButtonRestore.PerformClick()
    End Sub

    Private Sub OperationDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OperationDelete.Click
        ButtonDelete.PerformClick()
    End Sub

    Private Sub OperationDeleteAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OperationDeleteAll.Click
        ButtonDeleteAll.PerformClick()
    End Sub

    Private Sub TimerHelp_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TimerHelp.Tick
        If teksList.Length = 0 Then Exit Sub
        lbhelp.Text = teksList(index)
        index += 1
        If index >= teksList.Length Then
            index = 0
        End If
    End Sub

    Private Sub DataGridView1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseDown
        If e.Button = MouseButtons.Right Then
            Dim hitTestInfo As DataGridView.HitTestInfo = DataGridView1.HitTest(e.X, e.Y)

            If hitTestInfo.RowIndex >= 0 Then
                ' Pilih baris yang diklik kanan
                DataGridView1.ClearSelection()
                DataGridView1.Rows(hitTestInfo.RowIndex).Selected = True

                ' Tampilkan ContextMenuStrip di posisi kursor
                ContextMenuStrip1.Show(DataGridView1, e.Location)
            End If
        End If
    End Sub

    Private Sub ContextEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ContextEdit.Click
        ButtonEdit.PerformClick()
    End Sub

    Private Sub ContextDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ContextDelete.Click
        ButtonDelete.PerformClick()
    End Sub

    Private Sub HelpAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HelpAbout.Click
        frmAbout.Show()
    End Sub

    Private Sub HelpReadMe_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HelpReadMe.Click
        Try
            Process.Start(System.IO.Path.Combine(Application.StartupPath, "ReadMe.txt"))
        Catch ex As Exception

        End Try
    End Sub
End Class