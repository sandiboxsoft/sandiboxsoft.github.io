﻿Public Class frmAddNew
    Dim masterPath As String = "config.dll"

    Private Sub frmAddNew_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

    End Sub
    Private Sub frmAddNew_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Lang_Settings()
        ComboBox1.Items.Clear()
        ComboBox1.Items.AddRange(kategoricombo)
        Label1.Text = infopenting
        Label2.Text = infopenting
        If lbinfo.Text = "Edit" Then
            PictureBox1.Image = My.Resources.edit
            ButtonAdd.Text = buttonedit
            LabelHead.Text = edithead
            ButtonAdd.Image = My.Resources.edit
        Else
            ComboBox1.SelectedIndex = 0
        End If

    End Sub

    Private Sub ButtonClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonClose.Click
        Me.ActiveControl = Nothing
        Me.Close()
    End Sub

    Private Sub ButtonAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonAdd.Click
        Me.ActiveControl = Nothing
        If lbinfo.Text = "Edit" Then
            If TextBox1.Text = "" Or TextBox5.Text = "" Then
                MsgBox(infoaddnew, vbExclamation)
                Exit Sub
            End If

            Dim row As DataGridViewRow = Form2.DataGridView1.SelectedRows(0)
            row.Cells(0).Value = TextBox1.Text
            row.Cells(1).Value = ComboBox1.Text
            row.Cells(2).Value = TextBox2.Text
            row.Cells(3).Value = TextBox3.Text
            row.Cells(4).Value = TextBox4.Text
            row.Cells(5).Value = TextBox5.Text
            row.Cells(6).Value = TextBox6.Text
            row.Cells(7).Value = TextBox7.Text
            Form2.SaveData()
            Form2.cekdata()
            Me.Close()
        Else
            If TextBox1.Text = "" Or TextBox5.Text = "" Then
                MsgBox(infoaddnew, vbExclamation)
                Exit Sub
            End If

            ' Cek duplikat di kolom 0
            For Each row As DataGridViewRow In Form2.DataGridView1.Rows
                If Not row.IsNewRow Then
                    If String.Equals(row.Cells(0).Value.ToString.Trim, TextBox1.Text.Trim, StringComparison.OrdinalIgnoreCase) Then
                        MsgBox(infoduplikat, vbExclamation)
                        Exit Sub
                    End If
                End If
            Next
            Dim usernametext As String
            Dim phonetext As String
            Dim passrecov As String
            Dim notestext As String
            If String.IsNullOrEmpty(TextBox2.Text) Then
                usernametext = "-"
            Else
                usernametext = TextBox2.Text
            End If
            If String.IsNullOrEmpty(TextBox4.Text) Then
                phonetext = "-"
            Else
                phonetext = TextBox4.Text
            End If
            If String.IsNullOrEmpty(TextBox6.Text) Then
                passrecov = "-"
            Else
                passrecov = TextBox6.Text
            End If
            If String.IsNullOrEmpty(TextBox7.Text) Then
                notestext = "-"
            Else
                notestext = TextBox7.Text
            End If
            Form2.DataGridView1.Rows.Add(
                TextBox1.Text,
                ComboBox1.Text,
                usernametext,
                TextBox3.Text,
                phonetext,
                TextBox5.Text,
                passrecov,
                notestext
            )
            TextBox1.Clear()
            ComboBox1.SelectedIndex = 0
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            TextBox5.Clear()
            TextBox6.Clear()
            TextBox7.Clear()
            Form2.SaveData()
            Form2.cekdata()
            Me.Close()
        End If
     
    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = Chr(13) Then
            TextBox2.Focus()
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress
        If e.KeyChar = Chr(13) Then
            TextBox3.Focus()
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox3_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox3.KeyPress
        If e.KeyChar = Chr(13) Then
            TextBox4.Focus()
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox4_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox4.KeyPress
        If e.KeyChar = Chr(13) Then
            TextBox5.Focus()
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox5_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox5.KeyPress
        If e.KeyChar = Chr(13) Then
            TextBox6.Focus()
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox6_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox6.KeyPress
        If e.KeyChar = Chr(13) Then
            TextBox7.Focus()
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox7_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox7.KeyPress
        If e.KeyChar = Chr(13) Then
            ButtonAdd.Focus()
            e.Handled = True
        End If
    End Sub
End Class