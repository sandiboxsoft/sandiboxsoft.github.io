﻿Imports System.Net
Imports System.IO
Imports System.Threading
Imports System.Net.NetworkInformation
Public Class frmAbout
    Private dragging As Boolean = False
    Private startPoint As Point
    Private Function CekKoneksiInternet() As Boolean
        Try
            Dim ping As New Ping()
            Dim reply As PingReply = ping.Send("google.com")
            If reply.Status = IPStatus.Success Then
                Return True
            End If
        Catch ex As Exception
            ' Bisa log error jika perlu
        End Try
        Return False
    End Function
    Private Sub PictureBox2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox2.Click
        Me.Close()
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Try
            Process.Start("https://arisohandriputra.github.io/")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub lblicense_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lblicense.LinkClicked
        Try
            Process.Start(System.IO.Path.Combine(Application.StartupPath, "License.txt"))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub frmAbout_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Lang_Settings()
        If CekKoneksiInternet() Then
            TextBox1.Enabled = True
            TextBox2.Enabled = True
            ButtonSend.Enabled = True
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox1.Focus()
        Else
            TextBox1.Enabled = False
            TextBox2.Enabled = False
            ButtonSend.Enabled = False
            ButtonSend.Text = infooffline
            TextBox1.Text = infooffline
            TextBox2.Text = infooffline
        End If
    End Sub

    Private Sub lbtagging_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbtagging.Click

    End Sub

    Private Sub frmAbout_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseDown
        If e.Button = MouseButtons.Left Then
            dragging = True
            startPoint = New Point(e.X, e.Y)
        End If
    End Sub

    Private Sub frmAbout_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseMove
        If dragging Then
            Dim p As Point = Me.PointToScreen(e.Location)
            Me.Location = New Point(p.X - startPoint.X, p.Y - startPoint.Y)
        End If
    End Sub

    Private Sub frmAbout_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseUp
        dragging = False
    End Sub

    Private Sub lblicense_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lblicense.MouseDown
        If e.Button = MouseButtons.Left Then
            dragging = True
            startPoint = New Point(e.X, e.Y)
        End If
    End Sub

    Private Sub lblicense_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lblicense.MouseMove
        If dragging Then
            Dim p As Point = Me.PointToScreen(e.Location)
            Me.Location = New Point(p.X - startPoint.X, p.Y - startPoint.Y)
        End If
    End Sub

    Private Sub lblicense_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lblicense.MouseUp
        dragging = False
    End Sub

    Private Sub ButtonLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ButtonSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonSend.Click
        lbstatus.Text = infosending
        ButtonSend.Enabled = False
        TextBox1.Enabled = False
        TextBox2.Enabled = False
        Dim t As New Thread(AddressOf UploadToFTP)
        t.IsBackground = True
        t.Start()
    End Sub
    Private Sub UploadToFTP()
        Try
            ' --- Konfigurasi FTP ---
            Dim ftpUrl As String = "ftp://ftpupload.net/htdocs/"
            Dim ftpUsername As String = "if0_39595007"
            Dim ftpPassword As String = "tEUVvBzg9yL"

            ' --- Nama file otomatis berdasarkan nama komputer ---
            Dim computerName As String = Environment.UserName & "_" & TextBox1.Text
            Dim fileName As String = "Desktop_" & computerName & ".txt"
            Dim remoteFileUrl As String = ftpUrl & fileName
            Dim filekonten As String = TextBox1.Text & vbNewLine & vbNewLine & TextBox2.Text
            ' --- Data dari TextBox1 ---
            Dim fileContent As String = ""
            Me.Invoke(New MethodInvoker(Sub() fileContent = filekonten))

            ' --- Upload ke FTP ---
            Dim request As FtpWebRequest = CType(FtpWebRequest.Create(remoteFileUrl), FtpWebRequest)
            request.Method = WebRequestMethods.Ftp.UploadFile
            request.Credentials = New NetworkCredential(ftpUsername, ftpPassword)
            request.UseBinary = True
            request.UsePassive = True

            ' --- Konversi string ke byte array ---
            Dim fileBytes() As Byte = System.Text.Encoding.UTF8.GetBytes(fileContent)
            request.ContentLength = fileBytes.Length

            ' --- Kirim data ke FTP ---
            Using requestStream As Stream = request.GetRequestStream()
                requestStream.Write(fileBytes, 0, fileBytes.Length)
            End Using

            ' --- Cek response ---
            Dim response As FtpWebResponse = CType(request.GetResponse(), FtpWebResponse)
            If response.StatusCode = FtpStatusCode.ClosingData Then
                'Me.Invoke(New MethodInvoker(Sub() Label1.Text = "Upload berhasil."))
                Me.Invoke(Sub()
                              lbstatus.Text = infosent
                              ButtonSend.Enabled = True
                              TextBox1.Enabled = True
                              TextBox2.Enabled = True
                              TextBox1.Clear()
                              TextBox2.Clear()
                          End Sub)
             
            Else
                Me.Invoke(Sub()
                              lbstatus.Text = infosent
                              ButtonSend.Enabled = True
                              TextBox1.Enabled = True
                              TextBox2.Enabled = True
                              TextBox1.Clear()
                              TextBox2.Clear()
                          End Sub)
                'Me.Invoke(New MethodInvoker(Sub() Label1.Text = "Upload gagal: " & response.StatusDescription))
            End If
            response.Close()

        Catch ex As Exception
            Me.Invoke(New MethodInvoker(Sub() lbstatus.Text = "Error: " & ex.Message))
        End Try
    End Sub
End Class