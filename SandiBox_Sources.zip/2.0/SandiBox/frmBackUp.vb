﻿Imports System.Net
Imports System.IO
Imports System.Threading
Imports System.Net.NetworkInformation
Public Class frmBackUp
    Private Function CekKoneksiInternet() As Boolean
        Try
            Dim ping As New Ping()
            Dim reply As PingReply = ping.Send("google.com")
            If reply.Status = IPStatus.Success Then
                Return True
            End If
        Catch ex As Exception
            ' Bisa log error jika perlu
        End Try
        Return False
    End Function
    Private Sub frmBackUp_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CheckBox1.Checked = True
        Lang_Settings()        TextBox1.Text = My.Settings.ftpurl
        TextBox2.Text = My.Settings.ftpuser
        TextBox3.Text = My.Settings.ftppass        If String.IsNullOrEmpty(TextBox1.Text) Then            CheckBox3.Checked = False
        Else
            CheckBox3.Checked = True
        End If        If CekKoneksiInternet() Then
            CheckBox1.Enabled = True
        Else
            CheckBox1.Enabled = False
            CheckBox2.Enabled = False
            CheckBox3.Enabled = False
            Button1.Text = infooffline
        End If    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            ' Aktifkan ButtonLocal
            ButtonLocal.Enabled = True

            ' Nonaktifkan Button1 dan semua TextBox
            Button1.Enabled = False
            TextBox1.Enabled = False
            TextBox2.Enabled = False
            TextBox3.Enabled = False

            ' Nonaktifkan dan uncheck CheckBox2
            CheckBox2.Checked = False
        Else
            CheckBox2.Checked = True
        End If
    End Sub

    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked Then
            ' Aktifkan Button1 dan semua TextBox
            Button1.Enabled = True
            TextBox1.Enabled = True
            TextBox2.Enabled = True
            TextBox3.Enabled = True

            ' Nonaktifkan ButtonLocal
            ButtonLocal.Enabled = False

            ' Nonaktifkan dan uncheck CheckBox1
            CheckBox1.Checked = False
        Else
            ' Aktifkan kembali CheckBox1
            CheckBox1.Checked = True
        End If
    End Sub

    Private Sub ButtonLocal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonLocal.Click
        Form2.backdatalocal()
        Me.Close()
    End Sub
    Private Sub UploadToFTP()
        Try
            ' --- Konfigurasi FTP ---
            Dim ftpUrl As String = TextBox1.Text
            Dim ftpUsername As String = TextBox2.Text
            Dim ftpPassword As String = TextBox3.Text

            ' --- Nama file otomatis berdasarkan nama komputer ---
            Dim fileName As String = "base_backup.dll"
            Dim remoteFileUrl As String = ftpUrl & fileName
            Dim masterPath As String = "base_backup.dll"
            Dim saved = File.ReadAllText(masterPath)
            ' --- Data dari TextBox1 ---
            Dim fileContent As String = ""
            Me.Invoke(New MethodInvoker(Sub() fileContent = saved))

            ' --- Upload ke FTP ---
            Dim request As FtpWebRequest = CType(FtpWebRequest.Create(remoteFileUrl), FtpWebRequest)
            request.Method = WebRequestMethods.Ftp.UploadFile
            request.Credentials = New NetworkCredential(ftpUsername, ftpPassword)
            request.UseBinary = True
            request.UsePassive = True

            ' --- Konversi string ke byte array ---
            Dim fileBytes() As Byte = System.Text.Encoding.UTF8.GetBytes(fileContent)
            request.ContentLength = fileBytes.Length

            ' --- Kirim data ke FTP ---
            Using requestStream As Stream = request.GetRequestStream()
                requestStream.Write(fileBytes, 0, fileBytes.Length)
            End Using

            ' --- Cek response ---
            Dim response As FtpWebResponse = CType(request.GetResponse(), FtpWebResponse)
            If response.StatusCode = FtpStatusCode.ClosingData Then
                'Me.Invoke(New MethodInvoker(Sub() Label1.Text = "Upload berhasil."))
                Me.Invoke(Sub()
                              lbstatus.Text = infobacksuccess
                              lbstatus.ForeColor = Color.Lime
                              File.Delete("base_backup.dll")
                              CheckBox1.Enabled = True
                              CheckBox2.Enabled = True
                              CheckBox3.Enabled = True
                              Button1.Enabled = True
                              TextBox1.Enabled = True
                              TextBox2.Enabled = True
                              TextBox3.Enabled = True
                          End Sub)

            Else
                Me.Invoke(Sub()
                              lbstatus.Text = infobackfailed
                              lbstatus.ForeColor = Color.Orange
                              File.Delete("base_backup.dll")
                              CheckBox1.Enabled = True
                              CheckBox2.Enabled = True
                              CheckBox3.Enabled = True
                              Button1.Enabled = True
                              TextBox1.Enabled = True
                              TextBox2.Enabled = True
                              TextBox3.Enabled = True
                          End Sub)
                'Me.Invoke(New MethodInvoker(Sub() Label1.Text = "Upload gagal: " & response.StatusDescription))
            End If
            response.Close()

        Catch ex As Exception
            Me.Invoke(New MethodInvoker(Sub() lbstatus.Text = "Error: " & ex.Message))
        End Try
    End Sub
    Sub mulaibackup()
        File.Copy("base.dll", "base_backup.dll", True)
        backrest.EnkripsiFileLangsung("base_backup.dll", "Gamemetalslug@1")
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        mulaibackup()
        lbstatus.Text = infouploadftp
        CheckBox1.Enabled = False
        CheckBox2.Enabled = False
        CheckBox3.Enabled = False
        Button1.Enabled = False
        TextBox1.Enabled = False
        TextBox2.Enabled = False
        TextBox3.Enabled = False
        Dim t As New Thread(AddressOf UploadToFTP)
        t.IsBackground = True
        t.Start()
    End Sub

    Private Sub CheckBox3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox3.CheckedChanged
        If CheckBox3.Checked Then
            My.Settings.ftpurl = TextBox1.Text
            My.Settings.ftpuser = TextBox2.Text
            My.Settings.ftppass = TextBox3.Text
            My.Settings.Save()
        Else
            My.Settings.ftpurl = ""
            My.Settings.ftpuser = ""
            My.Settings.ftppass = ""
            My.Settings.Save()
        End If
    End Sub
End Class