﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAbout
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lbtagging = New System.Windows.Forms.Label()
        Me.lbauthor = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.lblicense = New System.Windows.Forms.LinkLabel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lbcopy = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lbsendfeedback = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ButtonSend = New System.Windows.Forms.Button()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.lbname = New System.Windows.Forms.Label()
        Me.lbmessage = New System.Windows.Forms.Label()
        Me.lbstatus = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.SandiBox.My.Resources.Resources.logo
        Me.PictureBox1.Location = New System.Drawing.Point(12, 41)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(72, 72)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(77, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(240, 65)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "SandiBox"
        '
        'lbtagging
        '
        Me.lbtagging.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbtagging.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbtagging.Location = New System.Drawing.Point(85, 102)
        Me.lbtagging.Name = "lbtagging"
        Me.lbtagging.Size = New System.Drawing.Size(232, 46)
        Me.lbtagging.TabIndex = 2
        Me.lbtagging.Text = "??"
        '
        'lbauthor
        '
        Me.lbauthor.AutoSize = True
        Me.lbauthor.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbauthor.Location = New System.Drawing.Point(85, 157)
        Me.lbauthor.Name = "lbauthor"
        Me.lbauthor.Size = New System.Drawing.Size(17, 15)
        Me.lbauthor.TabIndex = 3
        Me.lbauthor.Text = "??"
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.PictureBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox2.Image = Global.SandiBox.My.Resources.Resources.close
        Me.PictureBox2.Location = New System.Drawing.Point(307, 4)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(20, 20)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 7
        Me.PictureBox2.TabStop = False
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.LinkColor = System.Drawing.Color.Gold
        Me.LinkLabel1.Location = New System.Drawing.Point(86, 172)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(114, 17)
        Me.LinkLabel1.TabIndex = 8
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Ari Sohandri Putra"
        '
        'lblicense
        '
        Me.lblicense.BackColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.lblicense.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblicense.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblicense.LinkColor = System.Drawing.Color.White
        Me.lblicense.Location = New System.Drawing.Point(0, 0)
        Me.lblicense.Name = "lblicense"
        Me.lblicense.Size = New System.Drawing.Size(330, 29)
        Me.lblicense.TabIndex = 9
        Me.lblicense.TabStop = True
        Me.lblicense.Text = "??"
        Me.lblicense.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(90, 41)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 15)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "V.2.5.07.25"
        '
        'lbcopy
        '
        Me.lbcopy.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.lbcopy.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbcopy.Location = New System.Drawing.Point(0, 423)
        Me.lbcopy.Name = "lbcopy"
        Me.lbcopy.Size = New System.Drawing.Size(330, 31)
        Me.lbcopy.TabIndex = 11
        Me.lbcopy.Text = "??"
        Me.lbcopy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.Panel1.Location = New System.Drawing.Point(-8, 201)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(369, 2)
        Me.Panel1.TabIndex = 12
        '
        'lbsendfeedback
        '
        Me.lbsendfeedback.AutoSize = True
        Me.lbsendfeedback.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbsendfeedback.ForeColor = System.Drawing.Color.Yellow
        Me.lbsendfeedback.Location = New System.Drawing.Point(12, 215)
        Me.lbsendfeedback.Name = "lbsendfeedback"
        Me.lbsendfeedback.Size = New System.Drawing.Size(17, 15)
        Me.lbsendfeedback.TabIndex = 13
        Me.lbsendfeedback.Text = "??"
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(95, Byte), Integer), CType(CType(110, Byte), Integer))
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox1.Location = New System.Drawing.Point(12, 261)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox1.Size = New System.Drawing.Size(307, 23)
        Me.TextBox1.TabIndex = 1
        '
        'ButtonSend
        '
        Me.ButtonSend.BackColor = System.Drawing.Color.White
        Me.ButtonSend.BackgroundImage = Global.SandiBox.My.Resources.Resources.buttons
        Me.ButtonSend.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ButtonSend.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonSend.FlatAppearance.BorderColor = System.Drawing.Color.Silver
        Me.ButtonSend.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ButtonSend.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Azure
        Me.ButtonSend.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonSend.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSend.Image = Global.SandiBox.My.Resources.Resources.check_mark
        Me.ButtonSend.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ButtonSend.Location = New System.Drawing.Point(221, 388)
        Me.ButtonSend.Name = "ButtonSend"
        Me.ButtonSend.Size = New System.Drawing.Size(98, 38)
        Me.ButtonSend.TabIndex = 3
        Me.ButtonSend.Text = "??"
        Me.ButtonSend.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ButtonSend.UseVisualStyleBackColor = False
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(95, Byte), Integer), CType(CType(110, Byte), Integer))
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox2.Location = New System.Drawing.Point(12, 305)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox2.Size = New System.Drawing.Size(307, 77)
        Me.TextBox2.TabIndex = 2
        '
        'lbname
        '
        Me.lbname.AutoSize = True
        Me.lbname.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbname.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbname.Location = New System.Drawing.Point(12, 243)
        Me.lbname.Name = "lbname"
        Me.lbname.Size = New System.Drawing.Size(17, 15)
        Me.lbname.TabIndex = 17
        Me.lbname.Text = "??"
        '
        'lbmessage
        '
        Me.lbmessage.AutoSize = True
        Me.lbmessage.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbmessage.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbmessage.Location = New System.Drawing.Point(12, 287)
        Me.lbmessage.Name = "lbmessage"
        Me.lbmessage.Size = New System.Drawing.Size(17, 15)
        Me.lbmessage.TabIndex = 18
        Me.lbmessage.Text = "??"
        '
        'lbstatus
        '
        Me.lbstatus.AutoSize = True
        Me.lbstatus.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.lbstatus.Location = New System.Drawing.Point(12, 400)
        Me.lbstatus.Name = "lbstatus"
        Me.lbstatus.Size = New System.Drawing.Size(12, 15)
        Me.lbstatus.TabIndex = 19
        Me.lbstatus.Text = "-"
        '
        'frmAbout
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(330, 454)
        Me.ControlBox = False
        Me.Controls.Add(Me.lbstatus)
        Me.Controls.Add(Me.lbmessage)
        Me.Controls.Add(Me.lbname)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.ButtonSend)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.lbsendfeedback)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.lbcopy)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.lbauthor)
        Me.Controls.Add(Me.lbtagging)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblicense)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmAbout"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TopMost = True
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lbtagging As System.Windows.Forms.Label
    Friend WithEvents lbauthor As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents lblicense As System.Windows.Forms.LinkLabel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lbcopy As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lbsendfeedback As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents ButtonSend As System.Windows.Forms.Button
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents lbname As System.Windows.Forms.Label
    Friend WithEvents lbmessage As System.Windows.Forms.Label
    Friend WithEvents lbstatus As System.Windows.Forms.Label
End Class
