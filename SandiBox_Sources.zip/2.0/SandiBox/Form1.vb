﻿Imports System.IO

Public Class Form1
    Dim masterPath As String = "config.dll"
    Dim langpath As String = "language.dll"
    Dim dataPath As String = Environment.MachineName & ".dll"
    Public idleMinutes As Integer = 0
    Public labelcountdown As String
    Private dragging As Boolean = False
    Private startPoint As Point
    Private Sub ButtonLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonLogin.Click
        Me.ActiveControl = Nothing
        If String.IsNullOrEmpty(TextBox1.Text) Then
            MsgBox(infonopassword, vbCritical)
        Else
            If File.Exists(masterPath) Then
                Dim saved = File.ReadAllText(masterPath)
                If saved = Root.Encrypt(TextBox1.Text) Then
                    Me.Hide()
                    Form2.timeout = False
                    Form2.Show()
                    TextBox1.Clear()
                    lblStatus.Text = ""
                    lblStatus.Image = Nothing
                Else
                    lblStatus.Text = wrongpass
                    lblStatus.ForeColor = Color.Orange
                    TextBox1.Clear()
                    TextBox1.Focus()
                End If
            Else

                File.WriteAllText(masterPath, Root.Encrypt(TextBox1.Text))
                MsgBox(registersuccess, vbInformation)
                Lang_Settings()
                Timer1.Interval = 300000
                Timer1.Start()
                lblStatus.Text = loginsandi
                lblStatus.ForeColor = Color.White
                ButtonLogin.Text = loginhead
                ButtonLogin.Width = 87
                ButtonLogin.Location = New Point(192, 87)
                lblStatus.Image = Nothing
                Me.Height = 166
                TextBox1.Clear()
                TextBox1.Focus()
            End If
        End If
       
    End Sub
   
    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

    End Sub
    Sub cekbahasa()
        If File.Exists(langpath) Then
            '
        Else
            MsgBox("SandiBox suddenly exits! There are missing or damaged files. Please reinstall SandiBox from the official website.", vbCritical)
            Application.Exit()
        End If
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cekbahasa()
        Me.Icon = My.Resources.favicon
        Lang_Settings()
        If File.Exists(masterPath) Then
            Timer1.Interval = 300000 ' 2 minute
            Timer1.Start()
            lblStatus.Text = loginsandi
            lblStatus.ForeColor = Color.White
            ButtonLogin.Text = loginhead
            ButtonLogin.Width = 87
            Me.Height = 166
            ButtonLogin.Location = New Point(192, 87)
            lblStatus.Image = Nothing
        Else
            ButtonLogin.Text = createpassword
            ButtonLogin.Width = 141
            ButtonLogin.Location = New Point(138, 87)
            LabelHead.Text = creatnewpassword
            lblStatus.Text = creatnewpassword
            lblStatus.ForeColor = Color.Lime
            Me.Height = 137
            MsgBox(infonewpassword1 & vbNewLine & vbNewLine & infonewpassword2 & vbNewLine & infonewpassword3, vbExclamation)
        End If
      

    End Sub

    Private Sub Form1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseDown
        If e.Button = MouseButtons.Left Then
            dragging = True
            startPoint = New Point(e.X, e.Y)
        End If
    End Sub

    Private Sub Form1_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseMove
        idleMinutes = 0
        If dragging Then
            Dim p As Point = Me.PointToScreen(e.Location)
            Me.Location = New Point(p.X - startPoint.X, p.Y - startPoint.Y)
        End If
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        idleMinutes += 1
        If idleMinutes >= 5 Then
            Form2.timeout = True
            lblStatus.Text = autologout
            lblStatus.ForeColor = Color.Orange
            'lblStatus.Image = My.Resources.warning_info
            Form2.Close()
            Me.Show()
            idleMinutes = 0
        End If
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        If MsgBox(inforesetpassword1 & vbNewLine & vbNewLine & inforesetpassword2, MessageBoxButtons.OKCancel) = DialogResult.OK Then
            File.Delete("config.dll")
            File.Delete("base.dll")
            Application.Restart()
        Else
            TextBox1.Focus()
        End If
    End Sub

    Private Sub PictureBox2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox2.Click
        Application.Exit()
    End Sub

    Private Sub Form1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseUp
        dragging = False
    End Sub
End Class
