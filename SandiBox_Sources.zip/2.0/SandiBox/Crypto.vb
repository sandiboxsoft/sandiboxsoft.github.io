﻿Imports System.Text
Imports System.Security.Cryptography
Imports System.IO

Module Crypto
    Dim masterPath As String = "config.dll"
    Dim saved = File.ReadAllText(masterPath)
    Dim KEY As String = Root.Decrypt(saved)

    Public Function Encrypt(ByVal text As String) As String
        Dim buffer As Byte() = Encoding.UTF8.GetBytes(text)
        Dim md5 As New MD5CryptoServiceProvider()
        Dim tripleDes As New TripleDESCryptoServiceProvider()
        tripleDes.Key = md5.ComputeHash(Encoding.UTF8.GetBytes(KEY))
        tripleDes.Mode = CipherMode.ECB
        Dim transform = tripleDes.CreateEncryptor()
        Return Convert.ToBase64String(transform.TransformFinalBlock(buffer, 0, buffer.Length))
    End Function

    Public Function Decrypt(ByVal text As String) As String
        Try
            Dim buffer As Byte() = Convert.FromBase64String(text)
            Dim md5 As New MD5CryptoServiceProvider()
            Dim tripleDes As New TripleDESCryptoServiceProvider()
            tripleDes.Key = md5.ComputeHash(Encoding.UTF8.GetBytes(KEY))
            tripleDes.Mode = CipherMode.ECB
            Dim transform = tripleDes.CreateDecryptor()
            Return Encoding.UTF8.GetString(transform.TransformFinalBlock(buffer, 0, buffer.Length))

        Catch ex As CryptographicException
            ' Kesalahan saat dekripsi karena password salah
            'MsgBox("Password salah atau data rusak.", MsgBoxStyle.Critical, "Error Dekripsi")
            Return Nothing

        Catch ex As FormatException
            ' Kesalahan jika input bukan Base64 yang valid
            'MsgBox("Format data salah (bukan Base64).", MsgBoxStyle.Critical, "Error Format")
            Return Nothing

        Catch ex As Exception
            ' Penanganan umum
            'MsgBox("Kesalahan tidak diketahui: " & ex.Message, MsgBoxStyle.Critical, "Error")
            Return Nothing
        End Try
    End Function
End Module