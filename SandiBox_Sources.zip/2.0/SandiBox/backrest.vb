﻿Imports System.IO
Imports System.Security.Cryptography
Imports System.Text

Module backrest
    Public Sub EnkripsiFileLangsung(ByVal filePath As String, ByVal password As String)
        Try
            If Not File.Exists(filePath) Then
                ' MsgBox("File tidak ditemukan.", MsgBoxStyle.Critical, "Enkripsi Gagal")
                Exit Sub
            End If

            Dim key(31) As Byte ' 256-bit
            Dim iv(15) As Byte  ' 128-bit

            Dim pdb As New Rfc2898DeriveBytes(password, Encoding.ASCII.GetBytes("Gamemetalslug@1"))
            key = pdb.GetBytes(32)
            iv = pdb.GetBytes(16)

            Dim rijndael As New RijndaelManaged()
            rijndael.Key = key
            rijndael.IV = iv

            Dim data() As Byte = File.ReadAllBytes(filePath)
            Dim ms As New MemoryStream()
            Dim cs As New CryptoStream(ms, rijndael.CreateEncryptor(), CryptoStreamMode.Write)

            cs.Write(data, 0, data.Length)
            cs.Close()

            File.WriteAllBytes(filePath, ms.ToArray()) ' Timpa file asli
            'MsgBox("File berhasil dienkripsi.", MsgBoxStyle.Information, "Sukses")
        Catch ex As Exception
            'MsgBox("Terjadi kesalahan saat enkripsi: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Public Sub DekripsiFileLangsung(ByVal filePath As String, ByVal password As String)
        Try
            If Not File.Exists(filePath) Then
                'MsgBox("File tidak ditemukan.", MsgBoxStyle.Critical, "Dekripsi Gagal")
                Exit Sub
            End If

            Dim key(31) As Byte ' 256-bit
            Dim iv(15) As Byte  ' 128-bit

            Dim pdb As New Rfc2898DeriveBytes(password, Encoding.ASCII.GetBytes("Gamemetalslug@1"))
            key = pdb.GetBytes(32)
            iv = pdb.GetBytes(16)

            Dim rijndael As New RijndaelManaged()
            rijndael.Key = key
            rijndael.IV = iv

            Dim data() As Byte = File.ReadAllBytes(filePath)
            Dim ms As New MemoryStream(data)
            Dim cs As New CryptoStream(ms, rijndael.CreateDecryptor(), CryptoStreamMode.Read)

            Dim decrypted As New MemoryStream()
            Dim buffer(4096) As Byte
            Dim read As Integer
            Do
                read = cs.Read(buffer, 0, buffer.Length)
                If read > 0 Then decrypted.Write(buffer, 0, read)
            Loop While read > 0
            cs.Close()

            File.WriteAllBytes(filePath, decrypted.ToArray()) ' Timpa file asli
            'MsgBox("File berhasil didekripsi.", MsgBoxStyle.Information, "Sukses")
        Catch ex As CryptographicException
            MsgBox(infodataerror, MsgBoxStyle.Critical)
            File.Delete("config.dll")
            File.Delete("base.dll")
            Form2.Close()
            Form1.Show()
        Catch ex As Exception
            'MsgBox("Terjadi kesalahan saat dekripsi: " & ex.Message, MsgBoxStyle.Critical, "Error")
            File.Delete("config.dll")
            File.Delete("base.dll")
            Form2.Close()
            Form1.Show()
        End Try
    End Sub
End Module
