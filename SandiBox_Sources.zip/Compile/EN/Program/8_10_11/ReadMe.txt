 
   _____                 _ _ ____            
  / ____|               | (_)  _ \           
 | (___   __ _ _ __   __| |_| |_) | _____  __
  \___ \ / _` | '_ \ / _` | |  _ < / _ \ \/ /
  ____) | (_| | | | | (_| | | |_) | (_) >  < 
 |_____/ \__,_|_| |_|\__,_|_|____/ \___/_/\_\

         Store and Protect your Password
        © 2015 - 2025 Ari Sohandri Putra
            All Rights Reserved

======================================================================
>> WHAT IS SANDBOX?
SandiBox is a multi-layer secured password manager for Microsoft Windows.
It allows you to safely store your passwords locally and manage them
with strong encryption and privacy-focused design.

>> FEATURES
- Store passwords securely in an offline database.
- Backup your data to local storage or an FTP server.
- Restore data from `.sb` (SandiBox Backup) files.

>> SECURITY
SandiBox utilizes AES-256 encryption, combined with secure hashing and
confusion algorithms. Your data is 100% protected from:
- Brute-force decryption attempts
- Spyware and keyloggers
- Unauthorized screen capturing

>> IMPORTANT NOTES
* REMEMBER your master password. If you forget it, **your stored data
  cannot be recovered**.
* Perform regular backups to avoid data loss or forgotten passwords.

======================================================================

       Developed by Ari Sohandri Putra
         SandiBox - Since 2015

"This software is provided AS IS without warranty of any kind."