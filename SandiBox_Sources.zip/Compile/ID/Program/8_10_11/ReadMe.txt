   _____                 _ _ ____            
  / ____|               | (_)  _ \           
 | (___   __ _ _ __   __| |_| |_) | _____  __
  \___ \ / _` | '_ \ / _` | |  _ < / _ \ \/ /
  ____) | (_| | | | | (_| | | |_) | (_) >  < 
 |_____/ \__,_|_| |_|\__,_|_|____/ \___/_/\_\

         Simpan dan Lindungi Kata Sandi Anda
        © 2015 - 2025 Ari Sohandri Putra
            Hak Cipta Dilindungi Undang-Undang

======================================================================
>> APA ITU SANDBOX?
SandiBox adalah manajer kata sandi dengan keamanan berlapis untuk Microsoft Windows.
Ini memungkinkan Anda untuk menyimpan kata sandi secara lokal dengan aman dan
mengelolanya menggunakan enkripsi kuat dan desain yang berfokus pada privasi.

>> FITUR
- Menyimpan kata sandi dengan aman dalam basis data offline.
- Mencadangkan data Anda ke penyimpanan lokal atau server FTP.
- Memulihkan data dari file `.sb` (SandiBox Backup).

>> KEAMANAN
SandiBox menggunakan enkripsi AES-256, dikombinasikan dengan hashing aman dan
algoritma confusion. Data Anda terlindungi 100% dari:
- Upaya dekripsi brute-force
- Spyware dan keylogger
- Pengambilan tangkapan layar yang tidak sah

>> CATATAN PENTING
* INGAT kata sandi utama Anda. Jika Anda melupakannya, **data yang Anda simpan
  tidak dapat dipulihkan**.
* Lakukan pencadangan secara berkala untuk menghindari kehilangan data atau lupa kata sandi.

======================================================================

       Dikembangkan oleh Ari Sohandri Putra
         SandiBox - Sejak 2015

"Perangkat lunak ini disediakan SEBAGAIMANA ADANYA tanpa jaminan apa pun."